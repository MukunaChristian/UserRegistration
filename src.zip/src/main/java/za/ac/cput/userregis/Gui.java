/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.userregis;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author Dell
 */
public class Gui extends JFrame implements ActionListener {

    private JFrame mainframe;
    private JLabel label1, label2, label3, label4, label5, label6, label7, label8;
    private JPanel panelWest, panelEast, panelSouth, panelCenter, panelNorth, panelLabel;
    private JTextField txt1, txt2, txt3, txt4, txt5, txt6, txt7, tx8;
    private JButton btnSave, btnExit, btnClear;
    private Font ft;

    private JComboBox Title;

    private JRadioButton Female = new JRadioButton("Female");
    private JRadioButton Male = new JRadioButton("Male");
    private JCheckBox conditions = new JCheckBox("I agree the terms and conditions");

    public Gui() {
        super("User Regester");

        mainframe = new JFrame();
        mainframe.setPreferredSize(new Dimension(900, 700));

        panelNorth = new JPanel();
        panelWest = new JPanel();
        panelEast = new JPanel();
        panelSouth = new JPanel();
        panelCenter = new JPanel();
        panelLabel = new JPanel();

        label1 = new JLabel("Title");
        Title = new JComboBox(new String[]{"", "Dr,Miss,Mr,Mrs,Prof"});

        label2 = new JLabel("First Name");
        txt1 = new JTextField();

        label3 = new JLabel("Last Name");
        txt2 = new JTextField();

        label4 = new JLabel("Gender");
        Female = new JRadioButton("Female");
        Male = new JRadioButton("Male");

        label5 = new JLabel("Password");
        txt3 = new JTextField();

        label6 = new JLabel("Confirm Password");
        txt4 = new JTextField();

        label7 = new JLabel("Terms and Conditions");
        conditions = new JCheckBox("I agree the terms and conditions");

        btnSave = new JButton("Save ");
        btnClear = new JButton("Clear");
        btnExit = new JButton("Exit");

    }

    public void setGui() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setSize(700, 500);

        btnSave.addActionListener(this);
        btnClear.addActionListener(this);
        btnExit.addActionListener(this);

        panelWest.setLayout(new GridLayout(8, 2));
        panelEast.setLayout(new GridLayout(8, 2));
        panelSouth.setLayout(new GridLayout(1, 2));
        panelEast.setPreferredSize(new Dimension(250, 90));
        panelSouth.setPreferredSize(new Dimension(200, 30));
        panelWest.add(label1);
        panelWest.add(label2);
        panelWest.add(label3);
        panelWest.add(label4);
        panelWest.add(label5);
        panelWest.add(label6);
        panelWest.add(label7);
        panelEast.add(Title);
        panelEast.add(txt1);
        panelEast.add(txt2);
        panelEast.add(Female);
        panelEast.add(Male);
        panelEast.add(txt3);
        panelEast.add(txt4);
        panelEast.add(conditions);
        panelSouth.add(btnSave);
        panelSouth.add(btnClear);
        panelSouth.add(btnExit);
        mainframe.add(panelWest, BorderLayout.WEST);
        mainframe.add(panelEast, BorderLayout.EAST);
        mainframe.add(panelSouth, BorderLayout.SOUTH);

//        panelCenter.setLayout(new GridLayout(8, 2));
//        panelSouth.setLayout(new GridLayout(1, 3));
//
//        panelCenter.add(label1);
//        panelCenter.add(Title);
//
//        panelCenter.add(label2);
//        panelCenter.add(txt1);
//
//        panelCenter.add(label3);
//        panelCenter.add(txt2);
//
//        panelCenter.add(label4);
//        panelCenter.add(Female);
//        panelEast.add(Male);
//
//        panelCenter.add(label5);
//        panelCenter.add(txt3);
//
//        panelCenter.add(label6);
//        panelCenter.add(txt4);
//
//        panelCenter.add(label7);
//        panelCenter.add(conditions);
//
//        panelSouth.add(btnSave);
//        panelSouth.add(btnClear);
//        panelSouth.add(btnExit);
//
//        this.add(panelCenter, BorderLayout.CENTER);
//        this.add(panelEast, BorderLayout.EAST);
//        this.add(panelSouth, BorderLayout.SOUTH);
//        this.add(panelWest, BorderLayout.WEST);
//        this.add(panelSouth, BorderLayout.SOUTH);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
